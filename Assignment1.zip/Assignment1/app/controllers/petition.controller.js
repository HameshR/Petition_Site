const Petition = require('../models/petition.model');
const User = require('../models/user.model');
const Moment = require('moment');
const photoDirectory = './storage/photos/';
const defaultPhotoDirectory = '../../storage/default/';
const fs = require('mz/fs');
const mime = require('mime-types');

exports.create = async function(req, res) {
    try {
        let user_data = {
            "token": req.get('X-Authorization')
        };
        let result = await User.authenticateUser(user_data);
        if (result !== undefined) {
            let authorId = result['user_id'];
            let dateCreated = new Date();
            let petition_data = {
                "title": req.body.title,
                "description": req.body.description,
                "authorId": authorId,
                "categoryId": req.body.categoryId,
                "dateCreated": dateCreated,
                "closingDate": req.body.closingDate
            };
            let valid = petition_data['title'] != null && petition_data['title'] !== undefined;
            valid = valid && petition_data['description'] != null && petition_data['description'] !== undefined;
            valid = valid && petition_data['categoryId'] != null && petition_data['categoryId'] !== undefined;
            let categoryId = petition_data['categoryId'].toString();

            let closingDate = petition_data['closingDate'];

            const categoryReference = await Petition.validateCategoryID(categoryId);
            valid = valid && categoryReference !== undefined;
            valid = valid && dateCreated < new Date(closingDate);
            if (!valid) {
                res.status(400)
                    .send(null);
            } else {
                let title = petition_data['title'].toString();
                let description = petition_data['description'].toString();
                let values = [
                    [title],
                    [description],
                    [authorId],
                    [categoryId],
                    [dateCreated],
                    [closingDate]
                ];
                const result = await Petition.insert(values);
                let return_data = {
                    "petitionId": result
                };
                res.status(201)
                    .send(return_data);
            }
        } else {
            res.status(401)
                .send(`ERROR: Authentication token does not correspond to any logged in user.`);
        }
    } catch (err) {
        res.status(500)
            .send(`${err}`);
    }
};

exports.listPetitions = async function(req, res) {
    try {
        let valid = true;

        let startIndexVal;
        if (req.query.startIndex === undefined) {
            startIndexVal = 0;
        } else if (!isNaN(req.query.startIndex)) {
            startIndexVal = parseInt(req.query.startIndex);
        } else {
            valid = false;
        }
        let countVal;
        if (req.query.count === undefined) {
            countVal = null;
        } else if (!isNaN(req.query.count)) {
            countVal = parseInt(req.query.count);
        } else {
            valid = false;
        }
        let qVal;
        if (req.query.q === undefined) {
            qVal = null;
        } else if (req.query.q !== undefined) {
            qVal = req.query.q;
        } else {
            valid = false;
        }
        let categoryIdVal;
        if (req.query.categoryId === undefined) {
            categoryIdVal = null;
        } else if (!isNaN(req.query.categoryId)) {
            categoryIdVal = req.query.categoryId;
        } else {
            valid = false;
        }
        let authorIdVal;
        if (req.query.authorId === undefined) {
            authorIdVal = null;
        } else if (!isNaN(req.query.authorId)) {
            authorIdVal = req.query.authorId;
        } else {
            valid = false;
        }
        let sortByVal;
        if (req.query.sortBy === undefined) {
            sortByVal = 'SIGNATURES_DESC';
        } else if (['ALPHABETICAL_ASC', 'ALPHABETICAL_DESC', 'SIGNATURES_ASC', 'SIGNATURES_DESC'].includes(req.query.sortBy)) {
            sortByVal = req.query.sortBy;
        } else {
            valid = false;
        }
        if (valid) {
            let values = {
                "startIndex": startIndexVal,
                "count": countVal,
                "q": qVal,
                "categoryId": categoryIdVal,
                "authorId": authorIdVal,
                "sortBy": sortByVal
            };
            let result = await Petition.list(values);
            if (countVal) {
                console.log(result.slice(startIndexVal, (countVal+startIndexVal)));
                result = result.slice(startIndexVal, (countVal+startIndexVal));
            } else {
                console.log(result.slice(startIndexVal));
                result = result.slice(startIndexVal);
            }

            console.log(result);
            console.log("Starting Index: "+startIndexVal);
            console.log("Count Val: "+countVal);

            res.status(200)
                .send(result);
        } else {
            res.status(400)
                .send(`ERROR: Bad Request. Petition could not be found.`);
        }
    } catch (err) {
        res.status(500)
            .send(`${err}`);
    }
};

exports.getOnePetition = async function(req, res) {
    try {
        console.log(req.params);
        let petitionId = req.params.id;
        let result = await Petition.getOne(petitionId);
        if (result) {
            res.status(200)
                .send(result);
        } else {
            res.status(404)
                .send(`ERROR: No petition with the given ID ${petitionId} was found.`);
        }
    } catch (err) {
        res.status(500)
            .send(`${err}`);
    }
};

exports.listCategories = async function(req, res) {
    try {
        let result = await Petition.getCategories();
        res.status(200)
            .send(result);
    } catch (err) {
        res.status(500)
            .send(`${err}`);
    }
};

exports.getSignatures = async function(req, res) {
    try {
        console.log(req.params.id);
        let signature_data = {
            "petitionId": req.params.id
        };
        console.log("gets here");
        let petition = await Petition.checkPetitionExists(req.params.id);
        if (petition !== undefined) {
            let result = await Petition.getDetailedSignatures(signature_data);
            console.log(result.length);
            res.status(200)
                .send(result);
        } else {
            res.status(404)
                .send(`ERROR: There are no Petitions with Id ${req.params.id}`);
        }


    } catch (err) {
        res.status(500)
            .send(`${err}`);
    }
};

exports.sign = async function(req, res) {
    try {
        let user_data = {
            "token": req.get('X-Authorization')
        };
        let result = await User.authenticateUser(user_data);
        console.log(result);
        if (result !== undefined) {
            // user is authenticated
            let userId = result['user_id'];
            console.log("UserId:" + userId);
            let petition = await Petition.checkPetitionExists(req.params.id);
            if (petition !== undefined) {
                let values = {
                    "userId": userId,
                    "petitionId": req.params.id
                };
                let hasUserAlreadySigned = await Petition.checkUserSignedBefore(values);
                if (hasUserAlreadySigned.length) {
                    res.status(403)
                        .send(`ERROR: Forbidden. User has already signed this petition.`);
                } else {
                    //let dateSignedMoment = Moment();
                    let dateSigned = new Date();
                    console.log("Closing date taken from db:" + petition['closing_date']);
                    let petitionNotClosed;
                    if (petition['closing_date'] != "null") {
                        petitionNotClosed = true;
                    } else {
                        //petitionNotClosed = checkClosingDate(dateSignedMoment, petition['closing_date'].toString());
                        petitionNotClosed = dateSigned < petition['closing_date'];
                    }
                    if (petitionNotClosed === true) {
                        let values = [
                            [userId],
                            [req.params.id],
                            [dateSigned]
                        ];
                        await Petition.signPetition(values);
                        res.status(201)
                            .send("Created.");
                    } else {
                        console.log(dateSigned);
                        console.log(petition['closing_date']);
                        res.status(403)
                            .send(`ERROR: Forbidden. Petition is already closed.`);
                    }
                }
            } else {
                res.status(404)
                    .send(`ERROR: Petition not found.`);
            }
        } else {
            res.status(401)
                .send(`ERROR: Unauthorised.`);
        }
    } catch (err) {
        res.status(500)
            .send(`${err}`);
    }
};

exports.deleteSignature = async function(req, res) {
    try {
        let user_data = {
            "token": req.get('X-Authorization')
        };
        let result = await User.authenticateUser(user_data);
        if (result === undefined) {
            res.status(401)
                .send(`ERROR: Unauthorised.`);
            return;
        }
        // user is authenticated
        let petition = await Petition.checkPetitionExists(req.params.id);
        if (petition === undefined) {
            res.status(404)
                .send(`ERROR: Petition does not exist.`);
            return;
        }
        let petitionClosingDate = petition['closing_date'];
        let currentDate = Moment();

        if (!checkClosingDate(currentDate, petitionClosingDate)) {
            res.status(403)
                .send(`ERROR: Petition has closed.`);
            return;
        }

        let values = {
            "userId": result['user_id'],
            "petitionId": req.params.id
        };
        let hasUserAlreadySigned = await Petition.checkUserSignedBefore(values);

        if (!hasUserAlreadySigned.length) {
            res.status(403)
                .send(`ERROR: Forbidden. No signature to delete.`);
            return;
        }

        let author_id = parseInt(petition['author_id']);
        let user_id = parseInt(result['user_id']);
        if (author_id === user_id) {
            res.status(404)
                .send(`ERROR: Author can't sign their own petition, how could you delete it if it never existed?`);
            return;
        }

        await Petition.deleteSignature(values);
        res.status(200)
            .send(`Signature deleted.`);
    }

     catch (err) {
        res.status(500)
            .send(`${err}`);
    }
};

exports.update = async function(req, res) {
    try {
        let user_data = {
            "token": req.get('X-Authorization')
        };
        let user = await User.authenticateUser(user_data);
        if (user === undefined) {
            res.status(401)
                .send(`ERROR: Unauthorised.`);
            return;
        }

        let petition = await Petition.checkPetitionExists(req.params.id);
        let petitionId = parseInt(req.params.id);
        let userId = parseInt(user['user_id']);

        if (petition === undefined) {
            res.status(404)
                .send(`ERROR: Petition not found.`);
            return;
        }

        let authorId = parseInt(petition['author_id']);
        if (userId !== authorId) {
            res.status(403)
                .send(`ERROR: User ${userId} cannot edit petition ${petitionId} created by user ${authorId}.`);
            return;
        }

        console.log("Petition: " + petition);
        let closingDateVal = petition['closing_date'];
        if (closingDateVal) {
            closingDateVal = petition['closing_date'].toString();
        }

        let currentDate = Moment();

        if (petition['closing_date'] !== null && !checkClosingDate(currentDate, closingDateVal)) {
            res.status(403)
                .send("ERROR: Forbidden.");
            return;

        }
        console.log("CLosing date already in the db: " + petition['closing_date'])
        console.log("Closing date received as part of body: " + req.body.closingDate);

        if (req.body.closingDate !== undefined && checkClosingDate(currentDate, req.body.closingDate)) {
            closingDateVal = req.body.closingDate.toString();

        } else if (req.body.closingDate !== undefined) {
            res.status(400)
                .send(`ERROR: Closing date must be in the future.`);
            return;

        }

        let titleVal = petition["title"];
        if (req.body.title !== undefined) {
            titleVal = req.body.title;
        }

        let descriptionVal = petition["description"];
        if (req.body.description !== undefined) {
            descriptionVal = req.body.description;
        }

        let categoryIdVal = parseInt(petition["category_id"]);

        if (req.body.categoryId !== undefined) {
            let category = await Petition.validateCategoryID(req.body.categoryId);
            if (category === undefined) {
                res.status(400)
                    .send(`ERROR: Bad Request.`);
                return;

            } else {
                categoryIdVal = parseInt(req.body.categoryId);
            }
        }
        let values = {
            "petitionId": petitionId,
            "title": titleVal,
            "description": descriptionVal,
            "closingDate": closingDateVal,
            "categoryId": categoryIdVal
        };

        await Petition.updatePetition(values);
        res.status(200)
            .send(`Successfully updated petition.`);
        return;
    } catch (err) {
        console.log(err);
        res.status(500)
            .send(console.log(`${err}`));
    }
};

exports.deletePetition = async function(req, res) {
    try {
        let user_data = {
            "token": req.get('X-Authorization')
        };
        let user = await User.authenticateUser(user_data);
        if (user === undefined) {
            res.status(401)
                .send(`ERROR: Unauthorised.`);
            return;
        }

        let petition = await Petition.checkPetitionExists(req.params.id);
        let petitionId = parseInt(req.params.id);
        let userId = parseInt(user['user_id']);

        if (petition === undefined) {
            res.status(404)
                .send(`ERROR: Petition not found.`);
            return;
        }

        let authorId = parseInt(petition['author_id']);
        if (userId !== authorId) {
            res.status(403)
                .send(`ERROR: User ${userId} cannot delete petition ${petitionId} created by user ${authorId}.`);
            return;
        }

        await Petition.deleteSignatures(req.params.id);
        await Petition.deletePetition(req.params.id);
        res.status(200)
            .send(`Successfully deleted petition ${req.params.id} and corresponding signatures.`);


    } catch (err) {
        res.status(500)
            .send(console.log(`${err}`));
    }
};

exports.getPhoto = async function(req, res) {
    try {
        let result = await Petition.getPhotoFilename(req.params.id);
        if (result === undefined) {
            res.status(404)
                .send('ERROR: User not found.');
        }
        if (result['photo_filename'] === null) {
            res.status(404)
                .send('ERROR: Filename not found.');
        }
        let filename = result['photo_filename'];
        let imageDetails;
        if (!await fs.exists(photoDirectory + filename)) {
            res.status(404)
                .send("ERROR: Image not found.");
        }
        const image = await fs.readFile(photoDirectory + filename);
        const mimeType = mime.lookup(filename);
        imageDetails = {image, mimeType};
        res.status(200)
            .contentType(imageDetails.mimeType).send(imageDetails.image);
    } catch (err) { 
        res.status(500)
            .send(console.log(`${err}`));
    }
};

exports.putPhoto = async function(req, res) {
    try {

        let user_data = {
            "token": req.get('X-Authorization')
        };
        let user = await User.authenticateUser(user_data);
        if (user === undefined) {
            res.status(401)
                .send('ERROR: Unauthorised.');
            return;
        }

        let petition = await Petition.checkPetitionExists(req.params.id);
        if (petition === undefined) {
            res.status(404)
                .send("ERROR: Petition does not exist.");
            return;
        }

        let paramId = parseInt(req.params.id);
        let userId = parseInt(user['user_id']);
        if (paramId !== userId) {
            res.status(403)
                .send('ERROR: Forbidden.');
            return;
        }
        //let replace = false;

        // if (user['photo_filename'] !== null && await fs.exists(photoDirectory + user['photo_filename'])) {
        //     await fs.unlinkSync(photoDirectory + user['photo_filename']);
        //     replace = true;
        // }

        const image = req.body;
        const contentTypes = ['png', 'jpeg', 'gif', 'jpg'];
        let imageContentType = req.get('Content-Type');
        imageContentType = imageContentType.split("/");
        imageContentType = imageContentType[1];
        let filename = `user_${paramId}.${imageContentType}`;

        if (!contentTypes.includes(imageContentType)) {
            res.status(400)
                .send("Image type invalid.");
            return;
        }

        await fs.writeFile(photoDirectory + filename, image, "utf8", () => {});

        let values = {
            "id": req.params.id,
            "filename": filename
        };

        await Petition.putPhotoFilename(values);

        if (user['photo_filename'] === null) {
            res.status(201)
                .send('Created.');
        } else {
            res.status(200)
                .send("Done.");
        }
    } catch (err) {
        res.status(500)
            .send(console.log(`${err}`));
    }
};

function checkClosingDate(d1, d2String)
{
    return d1.isBefore(d2String);
}
