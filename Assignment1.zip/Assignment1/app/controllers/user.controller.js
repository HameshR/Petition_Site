const User = require('../models/user.model');
const Crypto = require('crypto-js');
const TokenGenerator = require('uuid-token-generator');
const photoDirectory = './storage/photos/';
const defaultPhotoDirectory = '../../storage/default/';
const fs = require('mz/fs');
const mime = require('mime-types');
const bodyParser = require('body-parser');

/**
 * This method is used to register and add users to the database.
 * @param req Contains the body of the request, along with the
 * @param res
 * @returns {Promise<void>}
 */
exports.create = async function(req, res) {
    try {
        let user_data = {
            "name": req.body.name,
            "email": req.body.email,
            "password": req.body.password,
            "city": req.body.city,
            "country": req.body.country
        };
        let valid = user_data['name'] != null && user_data['name'] !== undefined;
        valid = valid && user_data['password'] != null && user_data['password'] !== undefined;
        valid  = valid && user_data['email'] != null && user_data['email'] !== undefined;
        let email = user_data['email'].toString();
        valid = valid && validateEmail(email);
        if (!valid) {
            res.status(400)
                .send(null);
        } else {
            let name = user_data['name'].toString();
            let password = user_data['password'].toString();
            password = Crypto.SHA256(password).toString();
            let city = null;
            if (user_data['city'] !== undefined && user_data['city'] != null) {
                city = user_data['city'].toString();
            }
            let country = null;
            if (user_data['country'] !== undefined && user_data['country'] != null) {
                country = user_data['country'].toString();
            }
            let values = [
                [name],
                [email],
                [password],
                [city],
                [country]
            ];
            const result = await User.insert(values);
            let return_data = {
                "userId": result
            };
            res.status(201)
                .send(return_data);
        }

    } catch (err) {
        if (err.code === "ER_DUP_ENTRY") {
            res.status(400)
                .send(`ERROR: Email ${req.body.email} already used to create another account.`);
        } else {
            res.status(500)
                .send(`${err}`);
        }
    }
};

exports.loginUser = async function(req, res) {
    try {
        let user_data = {
            "email": req.body.email,
            "password": req.body.password
        };
        let valid = user_data['password'] != null;
        let email = user_data['email'].toString();
        valid = valid && validateEmail(email);
        if (!valid) {
            res.status(400)
                .send(null);
        }
        let values = [
            [email]
        ];
        const result = await User.findByEmail(values);
        if (result && user_data['password']) {
            let password = user_data['password'].toString();
            let db_password = result['password'].toString();
            let userId = result['user_id'];
            password = Crypto.SHA256(password).toString();
            if (password === db_password) {

                // Need to find out what we are actually suppose to use for authentication tokens.
                let token = new TokenGenerator().generate();

                user_data = {
                    "userId": userId,
                    "token": token
                };
                await User.updateAuthTokenGivenID(user_data);
                res.status(200)
                    .send(user_data);
            } else {
                console.log("for some reason it ends here");
            }
        } else {
            res.status(400)
                .send("ERROR: Invalid details entered.");
        }
    } catch (err) {
        res.status(500)
            .send(`${err}`);
    }
};

exports.logoutUser = async function(req, res) {
    try {
        let user_data = {
            "token": req.get('X-Authorization')
        };
        let result = await User.checkAuthTokenExists(user_data);
        if (result) {
            await User.updateAuthTokenGivenToken(user_data);
            res.status(200)
                .send("User successfully logged out.");
        } else {
            res.status(401)
                .send(`ERROR: Token is not in use by any user.`);
        }
    } catch (err) {
        res.status(500)
            .send(`${err}`);
    }
};

exports.read = async function(req, res) {
    try {
        let user_data = {
            "token": req.get('X-Authorization')
        }
        let result = await User.authenticateUser(user_data);
        console.log(result);
        let user_details = await User.getOne(req.params.id);
        console.log(user_details);
        if (user_details === undefined) {
            res.status(404)
                .send(`ERROR: There is no user with the ID ${req.params.id}.`);
        } else if (result === user_details) {
            res.status(200)
                .send(result);
        } else {
            let return_data = {
                "name": user_details["name"],
                "city": user_details["city"],
                "country": user_details["country"]
            };
            res.status(200)
                .send(return_data);
        }
    } catch (err) {
        res.status(500)
            .send(`${err}`);
    }
};

exports.update = async function(req, res) {
    try {
        let user_data = {
            "token": req.get('X-Authorization')
        };
        console.log(req.params);
        let user = await User.authenticateUser(user_data);
        if (user !== undefined) {
            let userIdInt = parseInt(user['user_id']);
            let paramIdInt = parseInt(req.params.id);
            if (paramIdInt === userIdInt) {
                let valid;
                let passwordVal = Crypto.SHA256(user["password"]);
                if (req.body.password === undefined) {
                    valid = false;
                } else if (req.body.currentPassword !== undefined) {
                    console.log(Crypto.SHA256(req.body.currentPassword).toString());
                    console.log(user['password']);
                    valid = Crypto.SHA256(req.body.currentPassword).toString() === user["password"];
                    passwordVal = Crypto.SHA256(req.body.currentPassword).toString();
                } else {
                    valid = Crypto.SHA256(req.body.password).toString() === user["password"];
                }
                if (valid) {
                    // check if name is included in json
                    let nameVal = user["name"];
                    if (req.body.name !== undefined) {
                        nameVal = req.body.name;
                    }
                    let emailVal = user["email"];
                    if (req.body.email !== undefined && validateEmail(req.body.email)) {
                        emailVal = req.body.email;
                    }
                    let cityVal = user["city"];
                    if (req.body.city !== undefined) {
                        cityVal = req.body.city;
                    }
                    let countryVal = user["country"];
                    if (req.body.country !== undefined) {
                        countryVal = req.body.country;
                    }

                    let values = {
                        "user_id": user['user_id'],
                        "name": nameVal,
                        "email": emailVal,
                        "password": passwordVal,
                        "city": cityVal,
                        "country": countryVal
                    };
                    await User.updateUserDetails(values);
                    res.status(200)
                        .send("Successfully updated user's details.");

                } else {
                    res.status(400)
                        .send(`ERROR: Bad Request. Either password was not specified or wrong.`);
                }
            } else {
                res.status(403)
                    .send(`ERROR: User ${user['user_id']} cannot edit user details of User ${req.params.id}`);
            }
        } else {
            res.status(401)
                .send("ERROR: The authorization token does not correspond to any user.");
        }
    } catch (err) {
        if (err.code === "ER_DUP_ENTRY") {
            res.status(400)
                .send(`ERROR: Email ${req.body.email} already used to create another account.`);
        } else {
            res.status(500)
                .send(`${err}`);
        }
    }
};

exports.getPhoto = async function(req, res) {
    try {
        let result = await User.getPhotoFilename(req.params.id);
        if (result === undefined) {
            res.status(404)
                .send('ERROR: User not found.');
            return;
        }
        if (result['photo_filename'] === null) {
            res.status(404)
                .send('ERROR: Filename not found.');
            return;
        }
        let filename = result['photo_filename'];
        let imageDetails;
        if (!await fs.exists(photoDirectory + filename)) {
            res.status(404)
                .send("ERROR: Image not found.");
            return;
        }
        const image = await fs.readFile(photoDirectory + filename);
        const mimeType = mime.lookup(filename);
        imageDetails = {image, mimeType};
        res.status(200)
            .contentType(imageDetails.mimeType).send(imageDetails.image);
    } catch (err) {
        res.status(500)
            .send(console.log(`${err}`));
    }
};

exports.deletePhoto = async function(req, res) {
    try {
        let paramUser = await User.checkUserExists(req.params.id);
        if (paramUser === undefined) {
            res.status(404)
                .send("ERROR: User does not exist.");
            return;
        }

        let user_data = {
            "token": req.get('X-Authorization')
        };
        let user = await User.authenticateUser(user_data);
        if (user === undefined || parseInt(user['user_id']) !== parseInt(req.params.id)
        ) {
            res.status(401)
                .send('ERROR: Unauthorised.');
            return;
        }


        if (user['photo_filename'] === null) {
            res.status(404)
                .send('ERROR: Filename not found.');
            return;
        }
        let filename = user['photo_filename'];
        if (!await fs.exists(photoDirectory + filename)) {
            res.status(404)
                .send("ERROR: Image not found.");
            return;
        }
        await fs.unlinkSync(photoDirectory + filename);
        await User.clearPhotoFilename(req.params.id);
        res.status(200)
            .send(`Deleted file ${filename}.`);
    } catch (err) {
        res.status(500)
            .send(console.log(`${err}`));
    }
};

exports.putPhoto = async function(req, res) {
    try {
        let user_data = {
            "token": req.get('X-Authorization')
        };
        let user = await User.authenticateUser(user_data);
        if (user === undefined) {
            res.status(401)
                .send('ERROR: Unauthorised.');
            return;
        }
        let paramId = parseInt(req.params.id);
        let userId = parseInt(user['user_id']);
        if (paramId !== userId) {
            res.status(403)
                .send('ERROR: Forbidden.');
            return;
        }
        //let replace = false;

        // if (user['photo_filename'] !== null && await fs.exists(photoDirectory + user['photo_filename'])) {
        //     await fs.unlinkSync(photoDirectory + user['photo_filename']);
        //     replace = true;
        // }

        const image = req.body;
        const contentTypes = ['png', 'jpeg', 'gif', 'jpg'];
        let imageContentType = req.get('Content-Type');
        imageContentType = imageContentType.split("/");
        imageContentType = imageContentType[1];
        let filename = `user_${paramId}.${imageContentType}`;

        if (!contentTypes.includes(imageContentType)) {
            res.status(400)
                .send("Image type invalid.");
            return;
        }

        await fs.writeFile(photoDirectory + filename, image, "utf8", () => {});

        let values = {
            "id": req.params.id,
            "filename": filename
        };

        await User.putPhotoFilename(values);

        if (user['photo_filename'] === null) {
            res.status(201)
                .send('Created.');
        } else {
            res.status(200)
                .send("Done.");
        }
    } catch (err) {
        res.status(500)
            .send(console.log(`${err}`));
    }
};

function validateEmail(email)
{
    let re = /\S+@\S+\.\S+/;
    return re.test(email);
}