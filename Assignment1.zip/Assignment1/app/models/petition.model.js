const db = require('../../config/db');
const fs = require('mz/fs');
const Moment = require('moment');

const photoDirectory = './storage/photos/';
const defaultPhotoDirectory = './storage/default/';

exports.validateCategoryID = async function(categoryID) {
    const connection = await db.getPool();
    const q = `SELECT * FROM Category WHERE category_id = ${categoryID}`;
    const [[result], _] = await connection.query(q);
    return result;
};

exports.insert = async function(valsRecv) {
    let values = [valsRecv];
    const connection = await db.getPool();
    const q = 'INSERT INTO Petition (title, description, author_id, category_id, created_date, closing_date) VALUES (?)';
    const [result, _] = await connection.query(q, values);
    //connection.release();
    return result.insertId;
};

exports.list = async function(values) {
    let startIndex = values['startIndex'];
    let count = values['count'];
    let q = values['q'];
    let categoryId = values['categoryId'];
    let authorId = values['authorId'];
    let sortBy = values['sortBy'];
    let sortField = 'signatureCount';
    let sortDirection = 'DESC';
    if (sortBy === 'ALPHABETICAL_ASC') {
        sortField = 'title';
        sortDirection = 'ASC';
    } else if (sortBy === 'ALPHABETICAL_DESC') {
        sortField = 'title';
    } else if (sortBy === 'SIGNATURES_ASC') {
        sortField = 'signatureCount';
        sortDirection = 'ASC';
    }
    const connection = await db.getPool();

    const querySelect = `SELECT Petition.petition_id AS petitionId, Petition.title AS title, Category.name AS category,
                User.name AS authorName, (
                SELECT COUNT(*) FROM Signature WHERE Signature.petition_id = Petition.petition_id
                ) AS signatureCount `;
    const queryFrom = `FROM Petition LEFT OUTER JOIN Category ON Petition.category_id = Category.category_id LEFT OUTER 
                JOIN User on Petition.author_id = User.user_id `;

    let queryExtra = ``;
    if (authorId || q || categoryId) {
        queryExtra = queryExtra + 'WHERE '
    }
    if (authorId) {
        queryExtra = queryExtra + `Petition.author_id = ${authorId} `;
    }
    if (authorId && q) {
        queryExtra = queryExtra + `AND Petition.title LIKE '%${q}%' `;
    } else if (q) {
        queryExtra = queryExtra + `Petition.title LIKE '%${q}%' `;
    }
    if ((authorId || q) && categoryId) {
        queryExtra = queryExtra + `AND Petition.category_id = ${categoryId} `;
    } else if (categoryId) {
        queryExtra = queryExtra + `Petition.category_id = ${categoryId} `;
    }

    let queryOther = `ORDER BY ${sortField} ${sortDirection} `;

    const queryFull = querySelect + queryFrom + queryExtra + queryOther;

    console.log(queryFull);

    const [result, _] = await connection.query(queryFull);
    //connection.release();
    return result;
};

exports.getOne = async function(id) {
    const connection = await db.getPool();
    const q = `SELECT Petition.petition_id AS petitionId, Petition.title AS title, Category.name AS category, 
        User.name AS authorName, (
                SELECT COUNT(*) FROM Signature WHERE Signature.petition_id = Petition.petition_id
                ) AS signatureCount, 
        Petition.description AS description, Petition.author_id AS authorId, User.city AS authorCity, User.country AS 
        authorCountry, Petition.created_date AS createdDate, Petition.closing_date AS closingDate
        FROM Petition LEFT OUTER JOIN Category ON Petition.category_id = Category.category_id LEFT OUTER JOIN User on 
        Petition.author_id = User.user_id WHERE Petition.petition_id = ${id}`;
    const [ [rows] ] = await connection.query(q);
    //connection.release();
    return rows;
};

exports.getCategories = async function() {
    const connection = await db.getPool();
    const q = `SELECT category_id AS categoryId, name FROM Category`;
    const [result, _] = await connection.query(q);
    //connection.release();
    return result;
};

exports.getDetailedSignatures = async function(values) {
    let petitionId = values['petitionId'];
    const connection = await db.getPool();
    const q = ` SELECT Signature.signatory_id AS signatoryId, User.name AS name, User.city AS city, User.country AS country,
        Signature.signed_date AS signedDate
        FROM Signature LEFT OUTER JOIN User ON Signature.signatory_id = User.user_id
        WHERE Signature.petition_id = ${petitionId} ORDER BY signedDate ASC`;
    const [result, _] = await connection.query(q);
    //connection.release();
    return result;
};

exports.checkPetitionExists = async function(id) {
    const connection = await db.getPool();
    const q = `SELECT * FROM Petition WHERE petition_id = ${id}`;
    const [[result], _] = await connection.query(q);
    return result;
};

exports.signPetition = async function(values) {
    //let userId = values["userId"];
    //let petitionId = values["petitionId"];
    //let signedDate = values["dateSigned"];
    const connection = await db.getPool();
    //const q = `INSERT INTO Signature (signatory_id, petition_id, signed_date) VALUES (${userId}, ${petitionId}, ${signedDate})`;
    const q1 = `INSERT INTO Signature (signatory_id, petition_id, signed_date) VALUES (?, ?, ?)`;
    await connection.query(q1, values);
};

exports.checkUserSignedBefore = async function(values) {
    let userId = values["userId"];

    let petitionId = values["petitionId"];
    const connection = await db.getPool();
    const q = `SELECT * FROM Signature WHERE signatory_id = ${userId} AND petition_id = ${petitionId}`;
    const [result, _] = await connection.query(q);
    return result;
};

exports.deleteSignature = async function(values) {
    let userId = values['userId'];
    let petitionId = values['petitionId'];
    const connection = await db.getPool();
    const q = `DELETE FROM Signature WHERE signatory_id = ${userId} AND petition_id = ${petitionId}`;
    await connection.query(q);

};

exports.updatePetition = async function(values) {
    let petitionId = values['petitionId'];
    let title = values['title'];
    let description = values['description'];
    let closingDate = values['closingDate'];
    let categoryId = values['categoryId'];

    const connection = await db.getPool();
    console.log(closingDate);
    let q = `UPDATE Petition SET title = "${title}", description = "${description}", category_id = ${categoryId}`;
    if (closingDate) {
        let tempDate = new Moment(closingDate);
        let stringDate = tempDate.format("YYYY-MM-DD HH:mm:ss")
        q += `, closing_date = "${stringDate}"`;
    }

    q += ` WHERE petition_id = ${petitionId}`;
    console.log(q);
    await connection.query(q);


};

exports.deleteSignatures = async function(id) {
    const connection = await db.getPool();
    let q = `DELETE FROM Signature WHERE petition_id = ${id}`;
    await connection.query(q);
};

exports.deletePetition = async function(id) {
    const connection = await db.getPool();
    let q = `DELETE FROM Petition WHERE petition_id = ${id}`;
    await connection.query(q);
};

exports.getPhotoFilename = async function(id) {
    const connection = await db.getPool();
    let q = `SELECT photo_filename FROM Petition WHERE petition_id = ${id}`;
    const [[result], _] = await connection.query(q);
    return result;
};

exports.putPhotoFilename = async function(values) {
    let id = values['id'];
    let filename = values['filename'];
    const connection = await db.getPool();
    let q = `UPDATE Petition SET photo_filename = '${filename}' WHERE petition_id = ${id}`;
    console.log(q);
    await connection.query(q);
};
