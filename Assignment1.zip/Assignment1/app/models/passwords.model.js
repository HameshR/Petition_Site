const db = require('../../config/db');
const Crypto = require('crypto-js');

exports.hash = async function(password) {
    return Crypto.SHA256(password).toString();
};