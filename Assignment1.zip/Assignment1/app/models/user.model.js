const db = require('../../config/db');
const fs = require('mz/fs');

const photoDirectory = './storage/photos/';
const defaultPhotoDirectory = './storage/default/';

exports.insert = async function(valsRecv) {
    let values = [valsRecv];
    const connection = await db.getPool();
    const q = 'INSERT INTO User (name, email, password, city, country) VALUES (?)';
    const [result, _] = await connection.query(q, values);
    //connection.release();
    return result.insertId;
};

exports.findByEmail = async function(valsRecv) {
    let values = [valsRecv];
    const connection = await db.getPool();
    const q = 'SELECT user_id, password, auth_token FROM User WHERE email = ?';
    const [[result], _] = await connection.query(q, values);
    //connection.release();
    return result;
};

exports.updateAuthTokenGivenID = async function(values) {
    let userId = values['userId'];
    let token = values['token'];
    const connection = await db.getPool();
    const q = `UPDATE User SET auth_token = '${token}' WHERE user_id = '${userId}'`;
    await connection.query(q);
    //connection.release();
};

exports.updateAuthTokenGivenToken = async function(values) {
    let token = values['token'];
    const connection = await db.getPool();
    const q = `UPDATE User SET auth_token = NULL WHERE auth_token = '${token}'`;
    await connection.query(q);
    //connection.release();
};

exports.checkAuthTokenExists = async function(values) {
    let token = values['token'];
    console.log(token);
    const connection = await db.getPool();
    const q = `SELECT COUNT(*) FROM User WHERE auth_token = '${token}'`;

    let [[result], _] = await connection.query(q);
    //connection.release();

    return result['COUNT(*)'] > 0;
};

exports.getOne = async function(id) {
    const connection = await db.getPool();
    const q = `SELECT name, city, country, email FROM User WHERE user_id = ${id}`;
    const [ [rows] ] = await connection.query(q);
    return rows;
};

exports.authenticateUser = async function(values) {
    let token = values['token'];
    const connection = await db.getPool();
    const q = `SELECT * FROM User WHERE auth_token = '${token}'`;
    const [[result], _] = await connection.query(q, values);
    //connection.release();
    return result;
};

exports.updateUserDetails = async function(values) {
    // TODO: Implement method.
    let user_id = values["user_id"];
    let name = values["name"];
    let email = values["email"];
    let password =values["password"];
    let city = values["city"];
    let country = values["country"];

    const connection = await db.getPool();
    let q = `UPDATE User SET name = '${name}', email = '${email}', password = '${password}'`;

    if (city) {
        q += `, city = '${city}'`;
    }

    if (country) {
        q += `, country = '${country}'`;
    }

    q += ` WHERE user_id = ${user_id}`;
    await connection.query(q, values);

};

exports.getPhotoFilename = async function(id) {
    const connection = await db.getPool();
    let q = `SELECT photo_filename FROM User WHERE user_id = ${id}`;
    const [[result], _] = await connection.query(q);
    return result;
};

exports.clearPhotoFilename = async function(id) {
    const connection = await db.getPool();
    let q = `UPDATE User SET photo_filename = NULL WHERE user_id = ${id}`;
    await connection.query(q);
};

exports.putPhotoFilename = async function(values) {
    let id = values['id'];
    let filename = values['filename'];
    const connection = await db.getPool();
    let q = `UPDATE User SET photo_filename = '${filename}' WHERE user_id = ${id}`;
    await connection.query(q);
};

exports.checkUserExists = async function(id) {
    const connection = await db.getPool();
    let q = `SELECT * FROM User WHERE user_id = ${id}`;
    console.log(q);
    let [[result], _] = await connection.query(q);
    return result;
}
