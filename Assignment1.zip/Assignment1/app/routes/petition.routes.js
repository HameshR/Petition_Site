const petition = require('../controllers/petition.controller');

module.exports = function (app) {
    app.route(app.rootUrl + '/petitions')
        .post(petition.create)
        .get(petition.listPetitions);

    app.route(app.rootUrl + '/petitions/categories')
        .get(petition.listCategories);

    app.route(app.rootUrl + '/petitions/:id/signatures')
        .get(petition.getSignatures)
        .delete(petition.deleteSignature)
        .post(petition.sign);

    app.route(app.rootUrl + '/petitions/:id')
        .get(petition.getOnePetition)
        .patch(petition.update)
        .delete(petition.deletePetition);

    app.route(app.rootUrl + '/petitions/:id/photo')
        .get(petition.getPhoto)
        .put(petition.putPhoto);
};
