const user = require('../controllers/user.controller');

module.exports = function (app) {
    app.route(app.rootUrl + '/users/register')
        .post(user.create);

    app.route(app.rootUrl + '/users/login')
        .post(user.loginUser);

    app.route(app.rootUrl + '/users/logout')
        .post(user.logoutUser);

    app.route(app.rootUrl + '/users/:id')
        .get(user.read)
        .patch(user.update);

    app.route(app.rootUrl + '/users/:id/photo')
        .get(user.getPhoto)
        .delete(user.deletePhoto)
        .put(user.putPhoto);
};

