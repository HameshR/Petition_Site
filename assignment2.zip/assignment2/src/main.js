import Vue from 'vue'
import App from './components/App.vue'
import Home from './components/Home.vue'
import Petitions from './components/Petitions.vue'
import Petition from './components/Petition.vue'
import Registration from './components/Registration.vue'
import Login from './components/Login.vue'
import User from './components/User.vue'
import Create from './components/Create.vue'
import EditPetition from './components/EditPetition.vue'
import EditUser from './components/EditUser.vue'
import store from './store'
import '@babel/polyfill'
import Buefy from 'buefy'
import 'buefy/dist/buefy.css'
import axios from 'axios'
import VueAxios from 'vue-axios'
import VueRouter from 'vue-router'
import Vuex from 'vuex'
import VueSocialSharing from 'vue-social-sharing'

Vue.use(Buefy);
Vue.use(VueAxios, axios);
Vue.use(VueRouter);
Vue.use(Vuex)
Vue.use(VueSocialSharing)

if (localStorage.getItem('token') != null) {
  let payload = {'token': localStorage.getItem('token'), 'userId': localStorage.getItem('userId')}
  store.dispatch('validateByTokenAndUserId', payload).then()
}

const routes = [
  {
    path: "/",
    component: Home
  },
  {
    path: "/petitions/:petitionId",
    name: "petition",
    component: Petition
  },
  {
    path: "/petitions",
    name: "petitions",
    component: Petitions
  },
  {
    path: "/create",
    name: "create",
    component: Create
  },
  {
    path: "/users/register",
    name: "registration",
    component: Registration
  },
  {
    path: "/users/login",
    name: "login",
    component: Login
  },
  {
    path: "/users/:userId",
    name: "user",
    component: User
  },
  {
    path: "/users/:userId/edit",
    name: "editUser",
    component: EditUser
  },
  {
    path: "/petitions/:petitionId/edit",
    name: "editPetition",
    component: EditPetition
  }
];

const router = new VueRouter({
  routes: routes,
  mode: 'history'
});

new Vue({
  el: '#app',
  router: router,
  render: h => h(App)
});
