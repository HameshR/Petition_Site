<template>

  <div v-if="!errorFlag" class="whole">
    <div class="container">

      <div class="card">

        <div v-if="this.user" class="card-content">
          <h1 class="title">{{this.user.name}}</h1>

          <div class="content">
            <table class="table-profile">
              <tr>
                <td colspan="1"></td>
                <th colspan="2"></th>
              </tr>
              <tr>
                <td><strong>Email:</strong></td>
                <td>{{this.user.email}}</td>
              </tr>
              <tr v-if="this.user.city">
                <td><strong>City:</strong></td>
                <td>{{this.user.city}}</td>
              </tr>
              <tr v-if="this.user.country">
                <td><strong>Country:</strong></td>
                <td>{{this.user.country}}</td>
              </tr>

            </table>

            <img class="hero_images" alt="<No Photo>" v-bind:src="userImageURL($route.params.userId)" @error.once="showDefaultUserImg">
            <table class="table-profile">
              <tr>
                <td v-if="store.getters.getAuthenticationStatus && store.getters.getUserId == $route.params.userId" class="edit_button">
                  <b-button @click="$router.push({ name: 'editUser', params: { petitionId: $route.params.userId }})" type="is-light">
                    Edit
                  </b-button></td>
              </tr>
            </table>


          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import store from '../store';
  import Vuex from 'vuex';
  import Vue from "vue";
  Vue.use(Vuex)

  export default {
    name: "User",
    data () {
      return {
        store: store,
        error: "",
        errorFlag: false,
        user: null,
        authenticated: true
      }
    },
    mounted() {
      this.checkAuthenticationStatus();
      this.getUser();
    },
    methods: {
      getUser: function() {
        if (!this.authenticated) {
          return
        }
        this.$http.get('http://localhost:4941/api/v1/users/' + this.$route.params.userId, {headers: {'X-Authorization': localStorage.getItem('token')}})
        .then((response) => {
          this.user = response.data;
        })
        .catch((error) => {
          if (error.response.status === 404) {
            this.$router.push('/')
          } else {
            window.alert(error)
          }

        })
      },
      userImageURL: function(idString) {
        let image = 'http://localhost:4941/api/v1/users/' + idString + '/photo/';
        return image;
      },
      showDefaultUserImg: function(event) {
        event.target.src = "/src/images/default_profile_picture.jpg";
      },
      checkAuthenticationStatus() {
        if (!store.getters.getAuthenticationStatus ||
          (store.getters.getAuthenticationStatus && (store.getters.getUserId != this.$route.params.userId))) {
          this.authenticated = false;
          this.$router.push('/')


        }
      }
    },

  }
</script>

<style scoped>

  .whole {
    padding-bottom: 40px;
    padding-top: 40px;
  }

  .container {
    background-color: rgba(255, 255, 255, 0.5);
    padding: 30px;
    border-radius: 10px;
    position: center;
  }

  .card {
    border-radius: 5px;
  }

  .edit_button {
    text-align: center;
    position: center;
    border-radius: 10px;
    margin: auto;
  }

  img{
    vertical-align: middle;
    width: auto;
    height: auto;
    max-height: 500px;
    border-radius: 10px;
    margin-left: auto;
    margin-right: auto;
    display: block;
  }

</style>
