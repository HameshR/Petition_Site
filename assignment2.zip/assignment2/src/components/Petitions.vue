<template>
  <div class="whole">
    <div v-if="errorFlag" style="color: red;">
      {{ error }}
    </div>

    <div v-if="!errorFlag" class="container">
      <h1 class="title">Petitions</h1>
      <b-field v-if="store.getters.getAuthenticationStatus" class="search_container" group-multiline grouped>
        <b-switch v-model="authorOnly" v-bind:change="getPetitionsParams()">
          My Petitions Only
        </b-switch>

      </b-field>
      <br v-if="store.getters.getAuthenticationStatus">
      <b-field class="search_container"  group-multiline grouped>
        <b-field>

          <b-select placeholder="Sort By" v-model="sortBy">
            <option value="SIGNATURES_DESC">Default</option>
            <option value="ALPHABETICAL_ASC">Title (A - Z)</option>
            <option value="ALPHABETICAL_DESC">Title (Z - A)</option>
            <option value="SIGNATURES_ASC">Signatures (Least - Most)</option>
          </b-select>
        </b-field>
        <b-field>
          <b-select placeholder="Category" v-model="categoryId">
            <option :value="null">No filter</option>
            <option v-for="category in categories"
                    :value="category.categoryId"
                    :key="category.categoryId">
              {{ category.name }}
            </option>
          </b-select>
        </b-field>
        <b-input v-model="q" placeholder="Search..." type="search" expanded>
        </b-input>
        <p class="control">
          <b-button @click="getPetitionsParams()" class="button is-info">Search</b-button>
        </p>
        <div class="control" v-if="store.getters.getAuthenticationStatus">
          <b-button class="control"
                    @click="$router.push({ name: 'create'})"
                    type="is-info">
            Add Petition
          </b-button>
        </div>
      </b-field>

      <b-table :data="petitions" :paginated="true" :per-page="perPage" :current-page.sync="currentPage">

        <template slot-scope="props">

          <b-table-column field="title" label="Title">
            {{ props.row.title }}
          </b-table-column>

          <b-table-column field="category" label="Category">
            {{ props.row.category }}
          </b-table-column>

          <b-table-column field="authorName" label="Author Name" centered>
            {{ props.row.authorName }}
          </b-table-column>

          <b-table-column label="">
            <img class="hero_images" alt="<No Photo>" v-bind:src="'http://localhost:4941/api/v1/petitions/' + props.row.petitionId + '/photo'">
          </b-table-column>


          <b-table-column field="signatureCount" label="Signature Count" centered>
            {{ props.row.signatureCount }}
          </b-table-column>

          <b-table-column class="view_button" label="More Information" centered>
            <b-button @click="$router.push({ name: 'petition', params: { petitionId: props.row.petitionId }}).catch(err => {})" type="is-light">
              View
            </b-button>
          </b-table-column>

        </template>
      </b-table>
    </div>
  </div>
</template>

<script>
  import store from '../store';
  import Vuex from 'vuex';
  import Vue from "vue";
  Vue.use(Vuex)

  export default {
      name: "Petitions",
    data () {
        return {
          store: store,
          error: "",
          errorFlag: false,
          petitions: [],
          q: null,
          sortBy: 'SIGNATURES_DESC',
          startIndex: null,
          count: null,
          categoryId: null,
          perPage: 10,
          authorOnly: false,
          currentPage: 1,
          categories: []
        }
    },
    mounted: function() {
        this.getPetitions();
        this.getCategories();
    },
    methods: {
        checkAuthenticationStatus() {
          return store.getters.getAuthenticationStatus();
        },
        getPetitions: function() {
          let resultParams = {
            sortBy: this.sortBy,
            categoryId: this.categoryId
          }

          if (store.getters.getAuthenticationStatus && this.authorOnly) {
            resultParams.authorId = store.getters.getUserId;
          }

          this.$http.get('http://localhost:4941/api/v1/petitions', {
            params: resultParams
          })
          .then((response) => {
            this.petitions = response.data;
          })
          .catch((error) => {
            this.error = error;
            this.errorFlag = true;
          });
        },
        getPetitionsParams: function() {
          if (this.q === "") {
            this.q = null;
          }

          let resultParams = {
            q: this.q,
            sortBy: this.sortBy,
            categoryId: this.categoryId
          };

          if (store.getters.getAuthenticationStatus && this.authorOnly) {
            resultParams.authorId = store.getters.getUserId;
          }

          this.$http.get('http://localhost:4941/api/v1/petitions', {
            params: resultParams
          }).then((response) => {
            this.petitions = response.data;
          })
            .catch((error) => {
              this.error = error;
              this.errorFlag = true;
            });
        },
        getCategories: function() {
          this.$http.get('http://localhost:4941/api/v1/petitions/categories')
          .then((response) => {
            this.categories = response.data;
          })
          .catch((error) => {
            this.error = error;
            this.errorFlag = true;
          });
        }
      }
    }
</script>

<style scoped>



  .whole {
    padding-bottom: 40px;
    padding-top: 40px;
  }

  .container {
    background-color: rgba(255, 255, 255, 0.5);
    padding: 30px;
    border-radius: 10px;
    position: center;
  }

  .hero_images {
    max-width: 100%;
    height: auto;
  }


</style>
