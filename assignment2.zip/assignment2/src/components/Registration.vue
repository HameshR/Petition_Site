<template>

  <div class="whole">
    <div class="container">
      <div class="white_box">
        <div class="form-container sign-in-container">
          <section>
            <form @submit.prevent="postRegistration()">
              <h1 class="title">Register</h1>

              <b-field label="Name" expanded >
                <b-input v-model="name" placeholder="Name..." required></b-input>
              </b-field>

              <b-field label="Email" expanded>
                <b-input type="email"
                         v-model="email"
                         placeholder="Email..."
                         required>
                </b-input>
              </b-field>

              <b-field label="Password" expanded>
                <b-input v-model="password" type="password" placeholder="Password..."
                         required></b-input>
              </b-field>

              <b-field label="Confirm Password"
                       :message="[{'Passwords do not match':isDisabled}]" expanded>
                <b-input v-model="confPassword" type="password" placeholder="Confirm Password..."
                         required></b-input>
              </b-field>

              <b-field label="City (Optional)" expanded >
                <b-input v-model="city" placeholder="City..." ></b-input>
              </b-field>

              <b-field label="Country (Optional)" expanded >
                <b-input v-model="country" placeholder="Country..." ></b-input>
              </b-field>

              <div class="field">
                <b-switch v-model="updatingImage">
                  Upload Image
                </b-switch>
              </div>

              <b-field v-if="updatingImage" class="file">
                <b-upload v-model="image"
                          drag-drop
                          accept="image/jpeg, image/png, image/gif, image/jpg"
                          native
                          required
                          validation-message="Please upload an image">
                  <section class="section">
                    <div class="content has-text-centered">
                      <p>
                        <b-icon
                          icon="upload"
                          size="is-large">
                        </b-icon>
                      </p>
                      <p>Drop your image here or click to upload</p>
                    </div>
                  </section>
                </b-upload>
                <span class="file-name" v-if="image">
            <strong>{{ image.name }}</strong>
            </span>
              </b-field>

              <b-button type="is-info" native-type="submit" :disabled="isDisabled">Submit</b-button>

            </form>
          </section>
        </div>
      </div>

    </div>
  </div>
</template>




<script>

  import store from "../store";

  export default {
      name: "Registration",
    data() {
      return {
        name: "",
        email: "",
        password: "",
        confPassword: "",
        city: "",
        country: "",
        image: null,
        updatingImage: false
      }
    },

    computed: {
      isDisabled() {
        return !(this.password === this.confPassword);
      }
    },

    methods: {
      updateUserImage() {
        this.$http.put('http://localhost:4941/api/v1/users/' + store.getters.getUserId + '/photo', this.image, {
          headers: {
            'X-Authorization': localStorage.getItem('token'),
            'Content-Type': this.image.type
          }
        })
        .then(() => {
          this.showMessage("Profile details saved and successfully logged in")
          this.$router.push({ name: 'user', params: { userId: store.getters.getUserId} })
        })
        .catch((error) => {
          window.alert(error)
        })
      },
      postRegistration: function() {
        if(this.password.length <= 0) {
          this.showWarning("Please select a password")
        } else {

          let resultBody = {
            name: this.name,
            email: this.email,
            password: this.password
          }

          if (this.city !== "" && this.country !== "") {
            resultBody = {
              name: this.name,
              email: this.email,
              password: this.password,
              city: this.city,
              country: this.country
            }
          } else if (this.city !== "" && this.country === "") {
            resultBody = {
              name: this.name,
              email: this.email,
              password: this.password,
              city: this.city
            }
          } else if (this.city === "" && this.country !== "") {
            resultBody = {
              name: this.name,
              email: this.email,
              password: this.password,
              country: this.country
            }
          }

          this.$http.post('http://localhost:4941/api/v1/users/register', resultBody)
            .then(() => {
              this.login();
            })
            .catch((error) => {
              window.alert(error)
            });
        }
      },
      showWarning(errorStatusCode) {
        this.$buefy.toast.open({
          duration: 3000,
          message: errorStatusCode,
          type: 'is-danger',
          position: 'is-top'
        })
      },
      login() {

        this.$http.post('http://localhost:4941/api/v1/users/login', {
          email: this.email,
          password: this.password
        }).then((response => {

          localStorage.setItem('token', response.data.token)
          localStorage.setItem('userId', response.data.userId)

          let payload = {'token': response.data.token, 'userId': response.data.userId}
          store.dispatch('validateByTokenAndUserId', payload).then()

          if (this.updatingImage) {
            this.updateUserImage();
          } else {
            this.showMessage("Profile details saved and successfully logged in")
            this.$router.push({ name: 'user', params: { userId: store.getters.getUserId} })
          }

        }))
          .catch((error) => {
            console.log(error)
          });
      },
      showMessage(message) {
        this.$buefy.toast.open({
          duration: 3000,
          message: message,
          type: 'is-success',
          position: 'is-top'
        })
      }
    }
  }
</script>


<style scoped>

  .whole {
    padding-bottom: 40px;
    padding-top: 40px;
  }

  .container {
    width: 600px;
    background-color: rgba(255, 255, 255, 0.5);
    padding: 30px;
    border-radius: 10px;
    position: center;
  }

  .white_box {
    background-color: white;
    padding: 30px;
    border-radius: 10px;
  }

</style>
