<template>


  <div class="whole">
    <div></div>
    <div class="bgimg w3-display-container w3-animate-opacity w3-text-white">
      <div class="w3-display-middle">
        <h1 class="w3-jumbo w3-animate-top">MY PETITION SITE</h1>
        <hr class="w3-border-grey" style="margin:auto;width:40%">
      </div>
    </div>
  </div>


</template>

<script>
    export default {
        name: "Home"
    }
</script>

<style scoped>
  .whole {
    padding-top: 60px;
    font-size: 200%;
  }

  h1 {font-family: "Raleway", sans-serif}

</style>
