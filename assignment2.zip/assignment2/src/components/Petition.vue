<template>

  <div v-if="!errorFlag" class="whole">
    <div class="container">

      <b-field class="back_button"  position="is-centered">
        <b-button @click="$router.push({ name: 'petitions'})" class="button is-light" extended>
          Back to Petitions
        </b-button>
      </b-field>




      <div class="card">

        <div class="card-content">
          <h1 class="title">{{this.petitionTitle}}</h1>

          <div class="content">
            <table class="table-profile">
              <tr>
                <td colspan="1"></td>
                <th colspan="2"></th>
              </tr>
              <tr>
                <td><strong>Description:</strong></td>
                <td>{{this.petitionDescription}}</td>
              </tr>
              <tr>
                <td><strong>Author Name:</strong></td>
                <td>{{this.petitionAuthorName}}</td>
              </tr>
              <tr>
                <td><strong>Signature Count:</strong></td>
                <td>{{this.petitionSignatureCount}}</td>
              </tr>
              <tr>
                <td><strong>Category:</strong></td>
                <td>{{this.petitionCategory}}</td>
              </tr>
              <tr>
                <td><strong>Created Date:</strong></td>
                <td>{{new Date(this.petitionCreatedDate).toDateString()}}</td>
              </tr>
              <tr v-if="this.petitionClosingDate">
                <td><strong>Closing Date:</strong></td>
                <td>{{new Date(this.petitionClosingDate).toDateString()}}</td>
              </tr>
              <tr>
                <td><strong>Petition Status:</strong></td>
                <td>{{ this.getPetitionStatus().toString() }}</td>
              </tr>
            </table>


            <table class="table-profile">
              <tr>
                <td>
                  <img class="hero_images" alt="<No Photo>" v-bind:src="'http://localhost:4941/api/v1/petitions/' + $route.params.petitionId + '/photo'">
                </td>
              </tr>
              <tr>
                <td>
                  <b-field>
                    <b-button class="share_button" type="is-light"><span class="icon"><i class="fab fa-twitter"></i></span>
                      <ShareNetwork network="twitter"
                                    :url="'http://localhost:8080/petitions/' + $route.params.petitionId"
                                    title="Take a look at this!"
                                    description="Share this petition to spread awareness!"
                                    quote="Vote up! - petitiond"
                                    hashtags="voteup,petitiond">Twitter</ShareNetwork></b-button>

                    <b-button class="share_button" type="is-light"><span class="icon"><i class="fab fa-envelope"></i></span>
                      <ShareNetwork network="email"
                                    :url="'http://localhost:8080/petitions/' + $route.params.petitionId"
                                    title="Take a look at this!"
                                    description="Share this petition to spread awareness!"
                                    quote="Vote up! - petitiond">Email</ShareNetwork></b-button>

                    <b-button class="share_button" type="is-light"><span class="icon"><i class="fab fa-reddit"></i></span>
                      <ShareNetwork network="reddit"
                                    :url="'http://localhost:8080/petitions/' + $route.params.petitionId"
                                    title="Take a look at this!"
                                    description="Share this petition to spread awareness!"
                                    quote="Vote up! - petitiond"
                                    hashtags="voteup,petitiond">Reddit</ShareNetwork></b-button>

                    <b-button class="share_button" type="is-light"><span class="icon"><i class="fab fa-facebook"></i></span>
                      <ShareNetwork network="facebook"
                                    :url="'http://canterbury.ac.nz:8080/petitions/' + $route.params.petitionId"
                                    title="Take a look at this!"
                                    description="Share this petition to spread awareness!"
                                    quote="Vote up! - petitiond"
                                    hashtags="voteup,petitiond">Facebook</ShareNetwork></b-button>
                  </b-field>

                </td>
              </tr>
              <tr>
                <td v-if="store.getters.getAuthenticationStatus && store.getters.getUserId == this.petitionAuthorId" :disabled="invalidClosingDate()" class="edit_button">
                  <b-button @click="$router.push({ name: 'editPetition', params: { petitionId: $route.params.petitionId }})" type="is-info">
                  Edit
                </b-button></td>
              </tr>
              <tr>
                <td v-if="store.getters.getAuthenticationStatus && store.getters.getUserId == this.petitionAuthorId"
                    class="delete_button"><b-button @click="confirmDelete" type="is-danger">
                  Delete
                </b-button></td>
              </tr>
              <tr>
                <td v-if="!invalidClosingDate() && store.getters.getAuthenticationStatus && store.getters.getUserId != this.petitionAuthorId" class="sign_button"><b-button :disabled="invalidClosingDate()" @click="toggleSigning" :type="signType">
                  {{ this.signButtonString }}
                </b-button></td>
              </tr>
            </table>
          </div>
        </div>
      </div>

      <br>

      <h1 class="title">Signatures</h1>

      <b-table :data="signatures">

        <template slot-scope="props">
          <b-table-column field="name" label="Name">
            {{ props.row.name }}
          </b-table-column>

          <b-table-column field="city" label="City" centered>
            {{ props.row.city }}
          </b-table-column>

          <b-table-column field="country" label="Country" centered>
            {{ props.row.country }}
          </b-table-column>

          <b-table-column field="profilePicture" label="Profile Picture">
            <img class="signatory_image"  :src="'http://localhost:4941/api/v1/users/' + props.row.signatoryId + '/photo'" @error.once="showDefaultUserImg">
          </b-table-column>
        </template>

      </b-table>
    </div>
  </div>
</template>

<script>
  import store from '../store';
  import Vuex from 'vuex';
  import Vue from "vue";
  Vue.use(Vuex)

  export default {
    name: "Petition",
    data () {
      return {
        store: store,
        error: "",
        errorFlag: false,
        signatures: [],
        petitionId: 0,
        petitionTitle: "",
        petitionDescription: "",
        petitionAuthorName: "",
        petitionSignatureCount: 0,
        petitionCreatedDate: "",
        petitionCategory: "",
        petitionClosingDate: "",
        petitionAuthorId: 0,
        signed: false,
        signButtonString: "",
        signType: 'is-info'
      }
    },
    beforeMount: function() {
      this.getSinglePetitionAndSignatures(this.$route.params.petitionId);
    },
    methods: {
      invalidClosingDate: function() {
        console.log(new Date(this.petitionClosingDate).toDateString())
        return this.petitionClosingDate && this.petitionClosingDate < new Date().toISOString();
      },
      getPetitionStatus: function() {
        if (!this.invalidClosingDate()) {
          if (this.signed) {
            return "Active and Signed";
          } else {
            return "Active and Unsigned"
          }
        } else {
          if (this.signed) {
            return "Closed and Signed"
          } else {
            return "Closed and Unsigned";
          }
        }
      },
      showMessage(message) {
        this.$buefy.toast.open({
          duration: 3000,
          message: message,
          type: 'is-success',
          position: 'is-top'
        })
      },
      toggleSigning: function() {
        if (this.signed) {
          this.$buefy.dialog.confirm({
            message: 'Are you sure you want to remove your signature from this petition?',
            type: 'is-danger',
            onConfirm: () => this.unSignPetition()
          })
        } else {
          this.signPetition();
        }
      },
      signPetition: function() {
        this.$http.post('http://localhost:4941/api/v1/petitions/' + this.petitionId + '/signatures', {},{headers: {'X-Authorization': localStorage.getItem('token')}})
          .then(() => {
            this.showMessage("Petition signed")
            this.getSignatures(this.petitionId);
            this.checkPetitionSigned();
          })
          .catch((error) => {
            window.alert(error)
          })
      },
      unSignPetition: function() {
        this.$http.delete('http://localhost:4941/api/v1/petitions/' + this.petitionId + '/signatures',{headers: {'X-Authorization': localStorage.getItem('token')}})
          .then(() => {
            this.showMessage("Signature removed")
            this.getSignatures(this.petitionId);
            this.checkPetitionSigned();
          })
          .catch((error) => {
            window.alert(error)
          })
      },
      confirmDelete: function() {
        this.$buefy.dialog.confirm({
          message: 'Are you sure you want to delete this petition?',
          type: 'is-danger',
          onConfirm: () => this.deletePetition()
        })
      },
      deletePetition: function() {
        this.$http.delete('http://localhost:4941/api/v1/petitions/' + this.$route.params.petitionId, {headers: {'X-Authorization': localStorage.getItem('token')}})
          .then(() => {
            this.showMessage("Petition deleted")
            this.$router.push({ name: 'petitions'})
          })
          .catch((error) => {
            this.error = error;
            this.errorFlag = true;
          });
      },
      checkPetitionSigned: function() {
        console.log(this.signatures.length)
        for (let i = 0; i < this.signatures.length; i++) {
          if (this.signatures[i].signatoryId == store.getters.getUserId) {
            console.log(this.signatures[i].signatoryId)
            console.log(store.getters.getUserId)
            this.signed = true;
            this.signButtonString = "Unsign";
            this.signType = 'is-danger';
            return
          }
        }
        this.signed=false;
        this.signButtonString = "Sign";
        this.signType = 'is-info';
      },
      getSinglePetition: function(id) {
        this.$http.get('http://localhost:4941/api/v1/petitions/' + id)
          .then((response) => {
            this.petitionId = response.data.petitionId;
            this.petitionTitle = response.data.title;
            this.petitionDescription = response.data.description;
            this.petitionAuthorName = response.data.authorName;
            this.petitionSignatureCount = response.data.signatureCount;
            this.petitionCreatedDate = response.data.createdDate;
            if (response.data.closingDate) {
              this.petitionClosingDate = response.data.closingDate;
            }
            this.petitionCategory = response.data.category;
            this.petitionAuthorId = response.data.authorId;
          })
          .catch((error) => {
            this.error = error;
            this.errorFlag = true;
          });
      },
      getSignatures: function(id) {
        this.$http.get('http://localhost:4941/api/v1/petitions/' + id + '/signatures')
          .then((response) => {
            this.signatures = response.data;
            this.checkPetitionSigned();
          })
          .catch((error) => {
            this.error = error;
            this.errorFlag = true;
          });
      },
      getSinglePetitionAndSignatures: function(id) {
        this.getSignatures(id);
        this.getSinglePetition(id);
      },
      userImageURL: function(idString) {
        let image = "'http://localhost:4941/api/v1/users/' + idString + '/photo/'";
        return image;
      },
      showDefaultUserImg: function(event) {
        event.target.src = "/src/images/default_profile_picture.jpg";
      }
    }
  }
</script>

<style scoped>

  .whole {
    padding-bottom: 40px;
    padding-top: 40px;
  }

  .container {
    background-color: rgba(255, 255, 255, 0.5);
    padding: 30px;
    border-radius: 10px;
    position: center;
  }

  .card {
    border-radius: 5px;
  }

  .edit_button, .delete_button, .sign_button, .hero_images {
    text-align: center;
    position: center;
    border-radius: 10px;
    margin: auto;
  }

  td img{
    vertical-align: middle;
    max-width: 100%;
    height: auto;
    border-radius: 10px;
    margin-left: auto;
    margin-right: auto;
    display: block;
  }

  .signatory_image {
    max-height: 300px;
    width: auto;
  }

  .share_button {
    text-align: center;
    position: center;
    border-radius: 10px;
    margin: auto;
  }

</style>
