<template>
  <div class="whole">
    <div v-if="store.getters.getAuthenticationStatus" class="container">
      <div class="white_box">
        <h1 class="title">Edit Profile</h1>
        <form @submit.prevent="confirmSubmit">

          <b-field label="Name" expanded >
            <b-input v-model="name" placeholder="Name..." required></b-input>
          </b-field>

          <b-field label="Email" expanded>
            <b-input type="email"
                     v-model="email"
                     placeholder="Email..."
                     required>
            </b-input>
          </b-field>

          <div class="field">
            <b-switch v-model="updatingCity">
              Update City
            </b-switch>
          </div>

          <b-field v-if="updatingCity" label="City" expanded>
            <b-input v-model="city"
                     placeholder="City..." required
                     validation-message="Please enter a city"></b-input>
          </b-field>

          <div class="field">
            <b-switch v-model="updatingCountry">
              Update Country
            </b-switch>
          </div>

          <b-field v-if="updatingCountry" label="Country" expanded>
            <b-input v-model="country"
                     placeholder="Country..." required
                     validation-message="Please enter a country"></b-input>
          </b-field>


          <div class="field">
            <b-switch v-model="updatingPassword">
              Update Password
            </b-switch>
          </div>

          <b-field v-if="updatingPassword" label="Current Password" expanded>
            <b-input v-model="oldPassword" type="password" placeholder="Current Password..."
                     required></b-input>
          </b-field>

          <b-field v-if="updatingPassword" label="New Password" expanded>
            <b-input v-model="newPassword1" type="password" placeholder="New Password..."
                     required></b-input>
          </b-field>

          <b-field v-if="updatingPassword" label="Confirm new Password"
                   :message="[{'Passwords do not match':isDisabled}]" expanded>
            <b-input v-model="newPassword2" type="password" placeholder="Confirm new Password..."
                     required></b-input>
          </b-field>

          <b-field class="image_div" position="is-centered" v-if="imageExists">
            <img class="user_image" alt="user image" :src="'http://localhost:4941/api/v1/users/' + this.$route.params.userId + '/photo'">
          </b-field>

          <div class="field">
            <b-switch v-model="updatingImage">
              Update Image
            </b-switch>
          </div>

          <b-field v-if="updatingImage" class="file">
            <b-upload v-model="image"
                      accept="image/jpeg, image/png, image/gif"
                      drag-drop
                      native
                      required
                      validation-message="Please upload an image, else toggle Update Image switch">
              <section class="section">
                <div class="content has-text-centered">
                  <p>
                    <b-icon
                      icon="upload"
                      size="is-large">
                    </b-icon>
                  </p>
                  <p>Drop your image here or click to upload</p>
                </div>
              </section>
            </b-upload>
            <span class="file-name" v-if="image">
              <strong>{{ image.name }}</strong>
            </span>
          </b-field>
          <div v-if="imageExists">
            <b-field>
              <b-button @click="confirmDeleteImage" class="is-danger">Remove Current Image</b-button>
            </b-field>
            <br>
          </div>


          <div>
            <b-button class="alignleft" type="is-danger" @click="cancel">Cancel</b-button>
            <b-button native-type="submit" class="alignright is-primary">Submit</b-button>
          </div>
          <br>



        </form>

      </div>

    </div>
  </div>


</template>


<script>
  import store from '../store';
  import Vuex from 'vuex';
  import Vue from "vue";
  Vue.use(Vuex)

  export default {
    name: "EditUser",

    data() {
      return {
        store: store,
        error: "",
        errorFlag: false,
        name: "",
        email: "",
        city: "",
        country: "",
        image: null,
        updatingImage: false,
        oldPassword: "",
        newPassword1: "",
        newPassword2: "",
        updatingPassword: false,
        updatingCity: false,
        updatingCountry: false,
        imageExists: false
      }
    },
    computed: {
      isDisabled() {
        return !(this.newPassword1 === this.newPassword2);
      },
    },
    mounted() {
      this.getCategories()
      this.getUser()
      this.getUserImage()
      this.checkAuthenticationStatus()
    },
    methods: {
      confirmSubmit: function() {
        this.$buefy.dialog.confirm({
          message: "Are you sure you want to save these changes?",
          onConfirm: () => this.editUser()
        })
      },
      getUserImage: function() {
        this.$http.get('http://localhost:4941/api/v1/users/' + this.$route.params.userId + '/photo', {headers: {'X-Authorization': localStorage.getItem('token')}})
        .then((response) => {
          this.image = response.data;
          this.imageExists = true;
        })
        .catch(() => {
          this.imageExists = false;
        })
      },
      confirmDeleteImage: function() {
        this.$buefy.dialog.confirm({
          message: "Are you sure you want to delete the current profile picture?",
          type: 'is-danger',
          onConfirm: () => this.deleteImage()
        })
      },
      deleteImage: function() {
        this.$http.delete('http://localhost:4941/api/v1/users/' + this.$route.params.userId + '/photo', {headers: {'X-Authorization': localStorage.getItem('token')}})
        .then(() => {
          this.image = null;
          this.imageExists = false;
          this.showMessage("Profile picture removed successfully")
        })
        .catch((error) => {
          console.log(error)
        })
      },
      showWarning(message) {
        this.$buefy.toast.open({
          duration: 3000,
          message: message,
          type: 'is-danger',
          position: 'is-top'
        })
      },
      cancel: function() {
        this.$buefy.dialog.confirm({
          message: "Are you sure you want to discard these changes?",
          type: 'is-danger',
          onConfirm: () => this.goBack()
        })
      },
      goBack() {
        this.$router.go(-1)
      },
      getUser: function() {
        this.$http.get('http://localhost:4941/api/v1/users/' + this.$route.params.userId, {headers: {'X-Authorization': localStorage.getItem('token')}})
          .then((response) => {
            this.name = response.data.name;
            this.email = response.data.email;
            if (response.data.city) {
              this.city = response.data.city;
              this.updatingCity = true;
            }
            if (response.data.country) {
              this.country = response.data.country;
              this.updatingCountry = true;
            }
          })
          .catch((error) => {
            this.error = error;
            this.errorFlag = true;
          });
      },
      getCategories: function() {
        this.$http.get('http://localhost:4941/api/v1/petitions/categories')
          .then((response) => {
            this.categories = response.data;
          })
          .catch((error) => {
            this.error = error;
            this.errorFlag = true;
          });
      },
      showMessage(message) {
        this.$buefy.toast.open({
          duration: 3000,
          message: message,
          type: 'is-success',
          position: 'is-top'
        })
      },
      showMessageExtended(message) {
        this.$buefy.toast.open({
          duration: 5000,
          message: message,
          type: 'is-success',
          position: 'is-top'
        })
      },
      dateFormatter(dt) {
        return dt.toISOString();
      },
      editUser: function() {
        let resultBody = {
          name: this.name,
          email: this.email
        }
        if (this.updatingCity) {
          resultBody.city = this.city;
        }
        if (this.updatingCountry) {
          resultBody.country = this.country;
        }
        if (this.updatingPassword) {
          resultBody.currentPassword = this.oldPassword;
          resultBody.password = this.newPassword1;
        }
        this.$http.patch('http://localhost:4941/api/v1/users/' + this.$route.params.userId, resultBody, {headers: {'X-Authorization': localStorage.getItem('token')}})
          .then(() => {
            if (this.updatingImage && this.image != null) {
              this.updateUserImage();
              this.showMessageExtended("Updating user image...");
              setTimeout(() => {this.$router.push({ name: 'user', params: { userId: this.$route.params.userId} });}, 5000)
              this.showMessage("Profile details saved");
            } else {
              this.showMessage("Profile details saved")
              this.$router.push({ name: 'user', params: { userId: this.$route.params.userId} })
            }
          })
          .catch((error) => {
            console.log(error.response.status)
            if (error.response.status === 400) {
              this.showWarning("Please enter the old password correctly")
            } else {
              window.alert(error)
            }
          });
      },
      checkAuthenticationStatus() {
        if (!store.getters.getAuthenticationStatus || !(store.getters.getUserId === this.$route.params.userId)) {
          this.showWarning("Unauthorised")
          this.$router.push('/')
        }
      },
      async updateUserImage() {
        this.$http.put('http://localhost:4941/api/v1/users/' + this.$route.params.userId + '/photo', this.image, {headers: {
            'X-Authorization': localStorage.getItem('token'),
            'Content-Type': this.image.type
          }})
          .catch((error) => {
            window.alert(error)
          })
      }
    }
  }
</script>

<style scoped>

  .whole {
    padding-bottom: 40px;
    padding-top: 40px;
  }

  .container {
    background-color: rgba(255, 255, 255, 0.5);
    padding: 30px;
    border-radius: 10px;
    position: center;
  }
  .white_box {
    background-color: white;
    padding: 30px;
    border-radius: 10px;
  }

  .user_image {
    max-height: 400px;
    max-width: 400px;
    display: block;
    margin-left: auto;
    margin-right: auto;
  }

  .alignleft {
    float: left;
  }

  .alignright {
    float: right;
  }

</style>
