<template>
  <b-navbar class="navigation" fixed-top shadow>
    <template slot="start">
      <b-navbar-item id="home" tag="router-link"
                     to="/"
                     href="#">
        Home
      </b-navbar-item>

    </template>

    <template slot="end">
      <b-navbar-item tag="div">
        <div class="buttons">
          <b-button  tag="router-link"
                     to="/petitions"
                     :type="petitionsTypeToggle()">
            Petitions
          </b-button>

          <b-button  v-if="store.getters.getAuthenticationStatus"
                     tag="router-link"
                     :to="'/users/' + store.getters.getUserId"
                     :type="profileTypeToggle()">
            Profile
          </b-button>

          <b-button v-if="!store.getters.getAuthenticationStatus"
                    tag="router-link"
                    to="/users/login"
                    :type="loginTypeToggle()">
            <strong>Login</strong>
          </b-button>
          <b-button v-if="!store.getters.getAuthenticationStatus"
                    tag="router-link"
                    to="/users/register"
                    :type="registerTypeToggle()">
            Register
          </b-button>

          <b-button  @click="confirmLogout"
                     v-if="store.getters.getAuthenticationStatus"
                     type="is-danger">
            Logout
          </b-button>
        </div>
      </b-navbar-item>
    </template>
  </b-navbar>
</template>


<script>
  import store from '../store';
  import Vuex from 'vuex';
  import Vue from "vue";
  Vue.use(Vuex)

  export default {
    name: "Navbar",
    data: () => {
      return {
        store: store,
        registerType: 'is-info',
        loginType: 'is-info',
        petitionsType: 'is-light',
        profileType: 'is-light'
      }
    },
    methods: {
      registerTypeToggle: function() {
        if (this.$route.name === 'registration') {
          return 'is-primary'
        } else {
          return this.registerType
        }
      },
      loginTypeToggle: function() {
        if (this.$route.name === 'login') {
          return 'is-primary'
        } else {
          return this.loginType
        }
      },
      petitionsTypeToggle: function() {
        if (this.$route.name === 'petitions') {
          return 'is-primary'
        } else {
          return this.petitionsType
        }
      },
      profileTypeToggle: function() {
        if (this.$route.name === 'user') {
          return 'is-primary'
        } else {
          return this.profileType
        }
      },
      logout: function() {
        this.$http.post('http://localhost:4941/api/v1/users/logout', {}, {headers: {'X-Authorization': localStorage.getItem('token')}})
          .catch(() => {
          });
        localStorage.clear()
        let payload = {'token': null, 'userId': null, 'authenticationStatus': false}
        store.dispatch('resetUserData', payload, {root:true});
        this.$router.push({path: '/users/login'});
      },
      confirmLogout: function() {
        this.$buefy.dialog.confirm({
          message: "Are you sure you want to logout now?",
          type: 'is-danger',
          onConfirm: () => this.logout()
        })
      }
    }
  }
</script>


<style>
  .buttons {
    /*padding: 10px;*/
  }

  #home {
    font-size: x-large;
  }

  .navigation {
    background-color: rgba(255, 255, 255, 0.9);
  }

  #home {
    color: black;
  }

</style>
