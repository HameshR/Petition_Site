<template>
  <div class="whole">
    <div class="container">
      <div v-if="store.getters.getAuthenticationStatus" class="white_box">
        <h1 class="title">Add Petition</h1>
        <form @submit.prevent="postPetition">

          <b-field label="Title" expanded>
            <b-input v-model="title" placeholder="Title..." required
                     validation-message="Please enter a title"></b-input>
          </b-field>

          <b-field label="Description" expanded>
            <b-input v-model="description" maxlength="500" type="textarea"
                     placeholder="Description..." required
                     validation-message="Please enter a description"></b-input>
          </b-field>

          <b-select label="Category" placeholder="Category..." required v-model="categoryId"
                    validation-message="Please choose a category">
            <option value="">No filter</option>
            <option v-for="category in categories"
                    :value="category.categoryId"
                    :key="category.categoryId">
              {{ category.name }}
            </option>
          </b-select>
          <br>

          <div class="field">
            <b-switch v-model="hasClosingDate">
              Petition Has Closing Date
            </b-switch>
          </div>

          <b-field v-if="hasClosingDate" label="Closing Date" expanded>
            <b-datepicker v-model="closingDate"
                          inline
                          :min-date="minDate"
                          required
                          validation-message="Please enter a valid closing date, it must be in the future">
            </b-datepicker>
          </b-field>

          <b-field class="file">
            <b-upload v-model="image"
                      drag-drop
                      accept="image/jpeg, image/png, image/gif, image/jpg"
                      native
                      required
                      validation-message="Please upload an image">
              <section class="section">
                <div class="content has-text-centered">
                  <p>
                    <b-icon
                      icon="upload"
                      size="is-large">
                    </b-icon>
                  </p>
                  <p>Drop your image here or click to upload</p>
                </div>
              </section>
            </b-upload>
            <span class="file-name" v-if="image">
            <strong>{{ image.name }}</strong>
            </span>
          </b-field>

          <div>
            <b-button class="alignleft" type="is-danger" @click="goBack">Cancel</b-button>
            <b-button native-type="submit" class="alignright is-primary">Submit</b-button>
          </div>
          <br>

        </form>
      </div>
    </div>

  </div>


</template>


<script>
  import store from '../store';
  import Vuex from 'vuex';
  import Vue from "vue";
  Vue.use(Vuex)

  export default {
      name: "Create",

    data() {
      return {
        store: store,
        error: "",
        errorFlag: false,
        title: "",
        description: "",
        categoryId: "",
        hasClosingDate: false,
        closingDate: new Date(),
        categories: [],
        image: null,
        minDate: new Date()
      }
    },
    mounted() {
      this.checkAuthenticationStatus()
      this.getCategories()
    },
    methods: {
      showWarning(message) {
        this.$buefy.toast.open({
          duration: 3000,
          message: message,
          type: 'is-danger',
          position: 'is-top'
        })
      },
      goBack() {
        this.$router.go(-1)
      },
      getCategories: function() {
        this.$http.get('http://localhost:4941/api/v1/petitions/categories')
          .then((response) => {
            this.categories = response.data;
          })
          .catch((error) => {
            this.error = error;
            this.errorFlag = true;
          });
      },
      showMessage(message) {
        this.$buefy.toast.open({
          duration: 3000,
          message: message,
          type: 'is-success',
          position: 'is-top'
        })
      },
      dateFormatter(dt) {
        return dt.toISOString();
      },
      postPetition: function() {
        console.log(localStorage.getItem('token'))
        let resultBody = {
          title: this.title,
          description: this.description,
          categoryId: this.categoryId
        }

        if (this.hasClosingDate === true) {
          resultBody = {
            title: this.title,
            description: this.description,
            categoryId: this.categoryId,
            closingDate: this.closingDate.getFullYear() + "-" + (this.closingDate.getMonth() + 1) + "-" + this.closingDate.getDate() + " " + this.closingDate.getHours() + ":" + this.closingDate.getMinutes() + ":" + this.closingDate.getSeconds() + "." + this.closingDate.getMilliseconds()
          }
        }
        let petitionId;
        this.$http.post('http://localhost:4941/api/v1/petitions', resultBody, {headers: {'X-Authorization': localStorage.getItem('token')}})
          .then((response) => {
            console.log(response)
            petitionId = response.data.petitionId;
            this.$http.put('http://localhost:4941/api/v1/petitions/' + petitionId + '/photo', this.image, {headers: {
              'X-Authorization': localStorage.getItem('token'),
              "Content-Type": this.image.type.toString()
              }})
            .then((response) => {
              console.log(response)
              this.$http.post('http://localhost:4941/api/v1/petitions/' + petitionId + '/signatures', {},{headers: {'X-Authorization': localStorage.getItem('token')}})
              .then(() => {
                this.showMessage("Petition details saved")
                this.$router.push({ name: 'petition', params: { petitionId: petitionId} })
              })
              .catch((error) => {
                window.alert(error)
              })

            })
            .catch((error) => {
              window.alert(error)
            })
          })
          .catch((error) => {
            window.alert(error)
          });

      },
      checkAuthenticationStatus() {
        if (!store.getters.getAuthenticationStatus) {
          this.$router.push('/')
        }
      }
    }
  }
</script>


<style scoped>

  .whole {
    padding-bottom: 40px;
    padding-top: 40px;
  }

  .container {
    background-color: rgba(255, 255, 255, 0.5);
    padding: 30px;
    border-radius: 10px;
    position: center;
  }
  .white_box {
    background-color: white;
    padding: 30px;
    border-radius: 10px;
  }

  .alignleft {
    float: left;
  }

  .alignright {
    float: right;
  }

  .alignleft {
    float: left;
  }

  .alignright {
    float: right;
  }

</style>
