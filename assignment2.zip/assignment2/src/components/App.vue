<template>
  <div id="app">
    <NavBar/>
    <div id="nav">
    </div>
    <router-view/>
  </div>
</template>

<script>
  import NavBar from './Navbar.vue';
  import Petition from './Petition.vue';
  import Petitions from './Petitions.vue';
  import Registration from './Registration.vue';
  import CreateOrEditPetition from './Create.vue';
  import Login from './Login.vue';

  const app = {
    name: 'app',
    components: {
      NavBar,
      Petition,
      Petitions,
      Registration,
      CreateOrEditPetition,
      Login
    },
    data: () => {
      return {
        NavBar,
        Petition,
        Petitions,
        Registration,
        CreateOrEditPetition,
        Login
      }
    },
  }
  export default app
</script>

<style>

  #nav {
    background-color: lightcyan;
  }

  html {
    background-size:cover;

    background: url("../images/green_trees_near_rock.jpg") no-repeat center center fixed;

    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
  }

</style>


