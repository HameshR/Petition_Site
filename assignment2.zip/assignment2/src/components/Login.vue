<template>
  <div class="whole">
    <div class="container">
      <div class="white_box">
        <div class="form-container sign-in-container">
          <section>
            <form action="" method="post" class="form-login">
              <h1 class="title">Login</h1>
              <b-field label="Email">
                <b-input class="help" placeholder="Email"
                         v-model="email"

                         maxlength="40">
                </b-input>
              </b-field>

              <b-field label="Password">
                <b-input placeholder="Password"
                         v-model="password"
                         type="password"
                         maxlength="20">
                </b-input>
              </b-field>
              <b-button @click="login"
                        type="is-info">
                Login
              </b-button>
            </form>
          </section>
        </div>
      </div>

    </div>
  </div>

</template>

<script>
  import store from '../store';

  export default {
    name: 'Login',
    data() {
      return {
        email: "",
        password: ""
      }
    },
    methods: {
      login() {

        this.$http.post('http://localhost:4941/api/v1/users/login', {
          email: this.email,
          password: this.password
        }).then((response => {

          localStorage.setItem('token', response.data.token)
          localStorage.setItem('userId', response.data.userId)

          let payload = {'token': response.data.token, 'userId': response.data.userId}
          store.dispatch('validateByTokenAndUserId', payload).then()
          this.showMessage("Successfully signed in")
          this.$router.push({ name: 'user', params: { userId: response.data.userId}})
        }))
          .catch((error => {
            console.log(error)
            this.displayError();
          }));
      },
      showMessage(message) {
        this.$buefy.toast.open({
          duration: 3000,
          message: message,
          type: 'is-success',
          position: 'is-top'
        })
      },
      displayError(){
        const message = "Incorrect email or password"
        this.$buefy.toast.open({
          duration:3000,
          message: message,
          type: 'is-danger',
          position: 'is-top'
        })
      }
    }
  }
</script>

<style scoped>
  @import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

  .white_box {
    background-color: white;
    padding: 30px;
    border-radius: 10px;
  }

  .whole {
    padding-bottom: 40px;
    padding-top: 40px;
  }

  .container {
    width: 600px;
    background-color: rgba(255, 255, 255, 0.5);
    padding: 30px;
    border-radius: 10px;
    position: center;
  }

</style>
